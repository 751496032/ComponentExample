package com.hzw.app;

/**
 * author: HZWei7
 * date:2018/11/18
 * description:
 */
public class AppConfig {
  public static final  String[] apps={"com.hzw.home.HomeApp",
                                        "com.hzw.cart.CartApp",
                                         "com.hzw.me.MeApp",
                                        "com.hzw.login.LoginApp"};
}
